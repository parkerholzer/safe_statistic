#' Align Two Normalized Template Spectra
#' 
#' This function aims to find an approximate radial velocity that gives a
#' Doppler factor for aligning two template spectra. It minimizes the
#' chi-squared statistic between the flux of one template and the
#' interpolated flux of the other template after Doppler-shifting its
#' wavelength axis. The template that is shifted must cover the full
#' wavelength range of the unshifted one. The more wavelengths covered
#' by the unshifted template, the less likely the optimizing is to get
#' stuck at a local minimum. In the end it should be visually obvious
#' for most templates that the two are aligned.
#' 
#'
#' @param wvl a vector of the wavelengths for the unshifted template spectrum
#' in units of Angstroms
#' @param flux a vector of the normalized flux for the unshifted template 
#' spectrum (unitless)
#' @param twvl a vector of the wavelengths for the template to be shifted in
#' units of Angstroms
#' @param tflux a vector of the normalized flux for the template to be shifted
#' (unitless)
#' @param rvmin a number giving the minimum radial velocity in units of m/s to be 
#' considered for shifting the template
#' @param rvmax a number giving the maximum radial velocity in units of m/s to be
#' considered for shifting the template
#' @param precision a number specifying how precise of a radial velocity
#' the returned value should be (in units of m/s)
#' @param return_chisq if set to \code{TRUE} the function returns all radial velocities
#' considered and their corresponding chi-squared values in addition to the 
#' optimal radial velocity
#' @return if \code{return_chisq} argument is set to \code{TRUE} the function
#' returns a list with the following components. Otherwise, only the optimal 
#' radial velocity is returned.
#' \itemize{
#' \item{bestrv: }{the optimal radial velocity in units of m/s}
#' \item{RVs: }{all radial velocities considered}
#' \item{ChiSq: }{all chi-squared values for the velocities considered}
#' }
#' @examples data(soap)
#' data(template)
#' output = alignspec(template$Wavelength, template$Flux, soap$Wavelength, soap$Flux, 
#' 20000, 80000, return_chisq = TRUE)
#' plot(output$RVs, output$ChiSq, xlab = "RV (m/s)", ylab = "Chi-squared")
#' plot(template$Wavelength, template$Flux, type='l', xlab = "Wavelength", ylab = "Normalized Flux")
#' lines(soap$Wavelength, soap$Flux, col=2, lty=2)
#' lines(soap$Wavelength*(1 + output$bestrv/299792458), soap$Flux, col=2)
#' @export
alignspec = function(wvl, flux, twvl, tflux, rvmin, rvmax, 
                     precision=0.01, return_chisq = F){
  if(return_chisq){
    Chisq = c()
    Rvs = c()
  }
  p = rvmax - rvmin
  rvs = seq(rvmin, rvmax, length.out=5)
  chisq = c()
  for(rv in rvs){
    doppfact = 1 + rv/299792458
    tw = twvl*doppfact
    if(tw[1] > wvl[1] | tw[length(tw)] < wvl[length(wvl)]){
      stop("Template doesn't cover full wavelength range")
    }
    tf = approx(tw, tflux, wvl)$y
    chisq = c(chisq, sum(((flux - tf)^2)/tf))
  }
  mdl = which.min(chisq)
  if(mdl==1){
    stop("RV range not low enough")
  }
  if(mdl==5){
    stop("RV range not high enough")
  }
  if(return_chisq){
    Chisq = c(Chisq, chisq)
    Rvs = c(Rvs, rvs)
  }
  p = rvs[mdl+1] - rvs[mdl-1]
  while(p > precision){
    chisq = c(chisq[mdl-1],0,chisq[mdl],0,chisq[mdl+1])
    rvs = c(rvs[mdl-1],mean(rvs[(mdl-1):mdl]),rvs[mdl],mean(rvs[mdl:(mdl+1)]),rvs[mdl+1])
    if(return_chisq) Rvs = c(Rvs, rvs[2], rvs[4])
    doppfact = 1 + rvs[2]/299792458
    tw = twvl*doppfact
    tf = approx(tw, tflux, wvl)$y
    chisq[2] = sum(((flux - tf)^2)/tf)
    doppfact = 1 + rvs[4]/299792458
    tw = twvl*doppfact
    tf = approx(tw, tflux, wvl)$y
    chisq[4] = sum(((flux - tf)^2)/tf)
    if(return_chisq) Chisq = c(Chisq, chisq[2], chisq[4])
    mdl = which.min(chisq)
    p = rvs[mdl+1] - rvs[mdl-1]
  }
  if(return_chisq){
    return(list(bestrv = rvs[mdl], RVs = Rvs, ChiSq = Chisq))
  }else{
    return(rvs[mdl])
  }
}
