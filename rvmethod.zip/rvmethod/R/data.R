#' Estimated template spectrum for the star 51 Pegasi (HD 217014)
#'
#' A small portion of the estimated template produced with the method of
#' \href{https://arxiv.org/abs/2005.14083}{Holzer et. al (2020)} on a set 
#' of 55 observed spectra from EXPRES.
#'
#' @format A data frame with 1893 rows and 2 variables:
#' \describe{
#'   \item{Wavelength}{the wavelength of the spectrum, in Angstroms}
#'   \item{Flux}{normalized flux of the spectrum, unitless}
#'   ...
#' }
#' @source \url{https://arxiv.org/abs/2003.08851}
"template"

#' Observed spectra for the star 51 Pegasi (HD 217014)
#'
#' 56 observed spectra as collected by EXPRES \strong{Petersburg et. al (2020)}.
#' Only the subset of the spectrum between 5000 and 5005 Angstroms is given here.
#'
#' @format A list with 56 elements, each of which has 2 variables:
#' \describe{
#'   \item{Wavelength}{the wavelength of the spectrum, in Angstroms}
#'   \item{Flux}{normalized flux of the spectrum, unitless}
#'   ...
#' }
#' @source \url{https://arxiv.org/abs/2003.08851}
"spectra"

#' Observed spectrum for the star 51 Pegasi (HD 217014)
#'
#' A small portion of one observed spectrum collected by EXPRES
#' \strong{Petersburg et. al (2020)}.
#'
#' @format A dataframe with 628 rows and the following 3 columns:
#' \describe{
#' \item{Wavelength}{the wavelength of the spectrum, in Angstroms}
#' \item{Flux}{normalized flux of the spectrum, unitless}
#' \item{Uncertainty}{the uncertainty of the flux measurements, unitless}
#' ...
#' }
#' @source \url{https://arxiv.org/abs/2003.08851}
"observed_spec"

#' Quiet SOAP spectrum
#'
#' A small portion of the SOAP spectrum with no stellar activity,
#' Doppler shift, nor photon noise
#' \strong{Dumusque et. al (2014)}.
#'
#' @format A dataframe with 12980 rows and the following 2 columns:
#' \describe{
#' \item{Wavelength}{the wavelength of the spectrum, in Angstroms}
#' \item{Flux}{normalized flux of the spectrum, unitless}
#' ...
#' }
#' @source \url{https://iopscience.iop.org/article/10.1088/0004-637X/796/2/132/meta}
"soap"

#' SOAP Absorption Features
#'
#' Absorption features found with the \code{findabsorptionfeatures}
#' function for the quiet SOAP spectrum. Hermite-Gaussian relative
#' amplitudes for calculating the SAFE statistic are also included.
#'
#' @format A dataframe with 4114 rows and the following columns:
#' \describe{
#' \item{Wv_lbounds}{the wavelength lower bounds of each feature, in Angstroms}
#' \item{Wv_ubounds}{the wavelength upper bounds of each feature, in Angstroms}
#' \item{Minflux}{the minimum normalized flux of each feature, unitless}
#' \item{MinWvl}{the wavelength of the minimum normalized flux, in Angstroms}
#' \item{Maxflux}{the maximum normalized flux of each feature, unitless}
#' \item{Gauss_amp,Gauss_mu,Gauss_sig}{Gaussian fit parameters of each feature}
#' \item{Continuum}{Pseudo-continuum of each feature}
#' \item{SOAPamp_d}{relative amplitude for the Hermite-Gaussian function degree d}
#' ...
#' }
"soapftrs"
