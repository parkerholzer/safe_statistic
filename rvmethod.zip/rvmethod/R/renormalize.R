#' Calculate median after removing low outliers
#' 
#' This function is used to renormalize the spectra after masking out
#' found absorption features.
#' 
#' @param wvl a vector of the wavelengths for the observed spectrum
#' @param flx a vector of the approximately normalized flux for the
#' observed spectrum
#' @param outputwvl a number specifying the wavelength to return the 
#' median flux for
#' @param windowsize a number specifying, in units of wavelength, how
#' large of a window around the \code{outputwvl} argument should be
#' considered for calculating the median
#' @return the median normalized flux for the window around \code{outputwvl}
#' @examples x = seq(5000, 5010, 0.01)
#' y = rnorm(length(x), 1.0, 0.01)
#' cntm = medn(x, y, 5005, 8)
#' @export
medn = function(wvl, flx, outputwvl, windowsize){
  w = which((wvl >= outputwvl - windowsize/2) & 
              (wvl <= outputwvl + windowsize/2) &
              (!is.na(flx)))
  iqr = IQR(flx[w])
  good = which(flx[w] >= max(c(quantile(flx[w], 0.25) - iqr, 0.95)))
  if(length(good) <= 2){
    return(1.0)
  }else{
    return(median(flx[w][good]))
  }
}

#' Renormalize an approximately-normalized spectrum
#' 
#' This function aims to renormalize a spectrum that has already been
#' approximately normalized. It does so by first using the
#' \code{findabsorptionfeatures} function to separate out the continuum
#' of the observed spectrum. Then by calculating a running median of 
#' the continuum.
#' 
#' @param spec a dataframe of the observed spectrum to be normalized. 
#' It is assumed that the dataframe has the following columns: ``Wavelength"
#' and ``Flux"
#' @param template a dataframe of the template spectrum. It is assumed
#' that the dataframe has the following columns: ``Wavelength" and ``Flux"
#' @param strongftrs a list of wavelength windows to exclude from the 
#' renormalization
#' @return a dataframe of the observed spectrum with the ``Flux" column
#' renormalized
#' @examples data("spectra")
#' data("template")
#' plot(spectra[[1]]$Wavelength, spectra[[1]]$Flux, type='l', 
#' xlab="Wavelength", ylab="Normalized Flux")
#' lines(template$Wavelength, template$Flux, col=2)
#' abline(h=1.0, lty=2, col=3)
#' strngftrs = list(c(4845,4880),c(5160,5200),c(5260,5290),c(6545,6585))
#' spec2 = normalize(spectra[[1]], template, strngftrs)
#' lines(spec2$Wavelength, spec2$Flux)
#' @export
normalize = function(spec, template, strongftrs){
  ftrs = findabsorptionfeatures(template$Wavelength, template$Flux,
                                pix_range = 8, minlinedepth = 0.008,
                                gamma = 0.08, alpha = 0.10)
  skeep = which((spec$Wavelength >= min(template$Wavelength)) &
                  (spec$Wavelength <= max(template$Wavelength)) &
                  (!is.na(spec$Flux)))
  ftridx = unlist(lapply(ftrs$wvbounds, 
                         function(bd) which(spec$Wavelength[skeep] >= bd[1] & 
                                              spec$Wavelength[skeep] <= bd[2])))
  ftridx = c(ftridx, unlist(lapply(strongftrs, 
                                   function(bd) which(spec$Wavelength[skeep] >= bd[1] & 
                                                                   spec$Wavelength[skeep] <= bd[2]))))
  cntm = setdiff(1:length(skeep), ftridx)
  k = as.integer((max(spec$Wavelength) - min(spec$Wavelength))/90)
  evalidx = as.integer(seq(1, length(cntm), length.out = max(c(2,k))))
  continuum0 = sapply(spec$Wavelength[skeep][cntm][evalidx], 
                      function(wv) medn(spec$Wavelength[skeep][cntm],
                                        spec$Flux[skeep][cntm],wv,8))
  continuum0 = approx(spec$Wavelength[skeep][cntm][evalidx], 
                      continuum0, 
                      xout=spec$Wavelength,
                      yleft=1, yright=1)$y
  spec$Flux = spec$Flux/continuum0
  return(spec)
}

#' Renormalize a set of observed spectra
#' 
#' This function parallelizes the \code{normalize} function for a set
#' of observed spectra that all share the same template spectrum.
#' 
#' @param spectra a list of dataframes of the observed spectra to be normalized. 
#' It is assumed that each dataframe has the following columns: ``Wavelength"
#' and ``Flux"
#' @param template a dataframe of the template spectrum. It is assumed
#' that the dataframe has the following columns: ``Wavelength" and ``Flux"
#' @param strongftrs a list of wavelength windows to exclude from the 
#' renormalization
#' @param cores a positive integer specifying the number of cores to 
#' parallelize across
#' @return a dataframe of the observed spectrum with the ``Flux" column
#' renormalized
#' @examples data("spectra")
#' data("template")
#' strngftrs = list(c(4845,4880),c(5160,5200),c(5260,5290),c(6545,6585))
#' output = renormalize(spectra, template, strngftrs, cores=1)
#' @export
renormalize = function(spectra, template, strongftrs, cores=5){
  return(parallel::mclapply(spectra, function(s) normalize(s, template, strongftrs),
                  mc.cores = cores))
}

