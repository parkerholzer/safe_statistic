#' Generalized Hermite-Gaussian Functions
#' 
#' Calculates the n'th degree Hermite-Gaussian function with a general
#' center and spread.
#' 
#' @param x a vector of values at which to evaluate the Hermite-Gaussian
#' function
#' @param n the degree of the Hermite-Gaussian function
#' @param mu the center parameter of the Hermite-Gaussian function
#' @param sig the spread parameter of the Hermite-Gaussian function
#' @return a vector of values of the Hermite-Gaussian function
#' @examples x = seq(-10,10,length.out=200)
#' y = hermgauss(x, 5)
#' @export
hermgauss = function(x, n, mu=0, sig=1){
  c = 1/sqrt(sig*(2^n)*factorial(n)*sqrt(pi))
  return(c*EQL::hermite((x-mu)/sig, n, prob=FALSE)*exp(-((x-mu)^2)/(2*sig^2)))
}

#' Doppler Shift a Spectrum
#' 
#' Adjust a spectrum to mimic a classical Doppler-shift due to a given
#' radial velocity (in units of m/s).
#' 
#' @param wvl wavelength axis of the spectrum
#' @param flx flux axis of the spectrum
#' @param rv radial velocity that determines how large the Doppler shift
#' should be. It is assumed that this velocity is in units of m/s and 
#' small enough to avoid effects of relativity.
#' @return the flux axis of the adjusted spectrum with the same 
#' wavelength solution as initially provided
#' @examples x = seq(4000, 4010, length.out=50)
#' y = x^2
#' ynew = doppshift(x, y, 10)
#' @export
doppshift = function(wvl, flx, rv){
  return(spline((1-rv/299792458)*wvl, flx, xout = wvl)$y)
}

#' Calculate the SAFE statistic
#' 
#' This function calculates the Stellar Activity F-statistic for Exoplanet
#' surveys (SAFE). The following assumptions are assumed to be true when using
#' this function:
#' \itemize{
#' \item{}{ All observed spectra have the wavelength axis in units of Angstroms}
#' \item{}{ All observed spectra have been properly normalized}
#' \item{}{ All instrumental effects have been properly corrected for
#' in all of the observed spectra}
#' }
#' Since the SAFE is particularly sensitive to assumption 2, we suggest
#' the following sequential implementation: (i) use the original set of
#' observed spectra to estimate the template with the \code{estimate_template}
#' function, (ii) apply the \code{renormalize} function to the original
#' set of observed spectra with the estimated template, (iii) use the
#' \code{estimate_template} function to get an updated template with the
#' renormalized spectra, and (iv) use the renormalized spectra and updated
#' template estimate in the \code{calc_safe} function.
#' 
#' @param spectra a list of all observed spectra of which to calculate the SAFE.
#' Each spectrum should be an item in the list and be formatted as a
#' data frame with the following columns:
#' \itemize{
#' \item{Wavelength: }{the wavelength of the spectrum in units of Angstroms}
#' \item{Flux: }{the continuum-normalized flux of the spectrum}
#' \item{Uncertainty: }{the uncertainty of the continuum normalized flux.
#' If this is not provided, the template spectrum is used to estimate the
#' uncertainty.}
#' }
#' @param template a template spectrum shared by all observed spectra
#' @param alignrv a radial velocity in units of m/s for approximately
#' aligning the template spectrum with the SOAP 2.0 spectrum. The 
#' \code{alignspec} function can provide this.
#' @param minwvl the minimum wavelength (in units of Angstroms) to use
#' @param maxwvl the maximum wavelength (in units of Angstroms) to use
#' @param cntm_bnds a length-2 vector with the lower and upper bounds
#' for a fitted continuum to be considered acceptable
#' @param cores the number of cores to parallelize over
#' @return a data frame, whose rows are in the same order as the observed
#' spectra in the \code{spectra} argument, with the following columns:
#' \itemize{
#' \item{Pvals: }{the p-values for testing the null hypothesis that
#' the only coefficient that is significantly different than 0 is b1}
#' \item{SAFE: }{the values of the SAFE statistic}
#' \item{Ns: }{the number of data points used in each regression}
#' \item{b0,b1,b2,b3,b4,b5: }{the fitted Hermite-Gaussian coefficients
#' for degree 0 - 5 respectively}
#' \item{t0,t1,t2,t3,t4,t5: }{the t-statistics for the Hermite-Gaussian
#' coefficients of degree 0 - 5 respectively}
#' }
#' 
#' @examples data(soap)
#' data(spectra)
#' tempest = estimate_template(spectra, cores = 1)
#' strngftrs = list(c(4845,4880),c(5160,5200),c(5260,5290),c(6545,6585))
#' spectra2 = renormalize(spectra, tempest, strngftrs, cores = 1)
#' rvest = rep(0, length(spectra2)) #this should be replaced with initial RV estimates
#' tempest2 = estimate_template(spectra2, vels = rvest, cores = 1)
#' output = alignspec(tempest2$Wavelength, tempest2$Flux, soap$Wavelength, soap$Flux, 
#' 20000, 80000, return_chisq = TRUE)
#' safe = calc_safe(spectra2, tempest2, output$bestrv, cntm_bnds=c(0.9, 1.1), cores = 1)
#' @export
calc_safe = function(spectra, template, alignrv, minwvl=5000,
                     maxwvl=7000, cntm_bnds = c(0.98,1.02),
                     cores = 10){
  utils::data("soapftrs", envir = environment())
  doppfact = 1 + alignrv/299792458
  soapftrs$Wv_lbounds = doppfact*soapftrs$Wv_lbounds
  soapftrs$Wv_ubounds = doppfact*soapftrs$Wv_ubounds
  soapftrs$MinWvl = doppfact*soapftrs$MinWvl
  soapftrs = soapftrs[(soapftrs$Wv_lbounds > max(c(minwvl, min(template$Wavelength)))) & 
                        (soapftrs$Wv_ubounds < min(c(maxwvl, max(template$Wavelength)))),]
  sftrs = list(wvbounds = lapply(1:(dim(soapftrs)[1]), function(i) c(soapftrs$Wv_lbounds[i], soapftrs$Wv_ubounds[i])),
                  min_wvl = soapftrs$MinWvl,
                  min_flx = soapftrs$Minflux,
                  max_flx = soapftrs$Maxflux)
  Features = Gaussfit(template$Wavelength, template$Flux, 
                      sftrs, for_safe = T)
  soapftrs$Gauss_amp = Features$Gauss_amp
  soapftrs$Gauss_mu = Features$Gauss_mu
  soapftrs$Gauss_sig = Features$Gauss_sig
  sftrs = NULL
  Features = NULL
  sig_cutoff = quantile(soapftrs$Gauss_sig, 0.75) + 
    IQR(soapftrs$Gauss_sig)
  soapftrs = soapftrs[(soapftrs$Gauss_sig <= sig_cutoff) & 
                      (soapftrs$Gauss_amp > 0) &
                      (soapftrs$Gauss_sig >= 0.001) &
                      (soapftrs$Continuum > cntm_bnds[1]) &
                      (soapftrs$Continuum < cntm_bnds[2]),]
  
  pixspc = template$Wavelength[2:length(template$Wavelength)] - template$Wavelength[1:(length(template$Wavelength)-1)]
  rightcutoffs = template$Wavelength[which(pixspc > 
                        quantile(pixspc, 0.75) + 15*IQR(pixspc))]
  rightcutoffs = c(rightcutoffs, template$Wavelength[length(template$Flux)])
  leftcutoffs = template$Wavelength[which(pixspc > 
                        quantile(pixspc, 0.75) + 15*IQR(pixspc))+1]
  leftcutoffs = c(template$Wavelength[1], leftcutoffs)
  
  safefit = function(tau){
    wvl = c()
    tempflx = c()
    obsflx = c()
    obsunc = c()
    for(i in 1:length(leftcutoffs)){
      keep = which(spectra[[tau]]$Wavelength > leftcutoffs[i] &
                     spectra[[tau]]$Wavelength < rightcutoffs[i])
      tkeep = which(template$Wavelength >= leftcutoffs[i] &
                      template$Wavelength <= rightcutoffs[i])
      if(length(tkeep) > 5 & length(keep) > 5){
        wvl = c(wvl, spectra[[tau]]$Wavelength[keep])
        obsflx = c(obsflx, spectra[[tau]]$Flux[keep])
        tempflx = c(tempflx, wave_match(template$Wavelength[tkeep], 
                                        template$Flux[tkeep],
                                        spectra[[tau]]$Wavelength[keep]))
        if("Uncertainty" %in% names(spectra[[tau]])){
          obsunc = c(obsunc, spectra[[tau]]$Uncertainty[keep])
        }else{
          obsunc = c(obsunc, sqrt(tempflx[(length(obsunc)+1):length(tempflx)]))
        }
      }
    }
    
    nonans = which(!is.na(obsflx))
    wvl = wvl[nonans]
    obsflx = obsflx[nonans]
    obsunc = obsunc[nonans]
    tempflx = tempflx[nonans]
    keep = which((wvl >= minwvl) & (wvl <= maxwvl))
    wvl = wvl[keep]
    obsflx = obsflx[keep]
    obsunc = obsunc[keep]
    tempflx = tempflx[keep]
    
    keep = c()
    doppvar = c()
    for(i in 1:(dim(soapftrs)[1])){
      w = which((wvl <= soapftrs$Wv_ubounds[i]) & (wvl >= soapftrs$Wv_lbounds[i]))
      if(length(w) > 3){
        keep = c(keep, w)
        diff = tempflx[w] - doppshift(wvl[w], tempflx[w], 20)
        x_design = sapply(0:5, function(d) hermgauss(wvl[w],d,mu=soapftrs$Gauss_mu[i],sig=soapftrs$Gauss_sig[i]))
        mdl = lm(diff ~ 0 + x_design)
        doppvar = c(doppvar, as.numeric(mdl$fitted.values)/20)
      }
    }
    Loadings = as.matrix(soapftrs[c("SOAPamp_0", "SOAPamp_2",
                                    "SOAPamp_3", "SOAPamp_4",
                                    "SOAPamp_5")])
    X = matrix(nrow = length(doppvar), ncol = 6)
    X[,1] = doppvar
    for(j in c(0,2,3,4,5)){
      v = c()
      for(i in 1:(dim(soapftrs)[1])){
        w = which((wvl <= soapftrs$Wv_ubounds[i]) &
                    (wvl >= soapftrs$Wv_lbounds[i]))
        if(length(w) > 3){
          if(j==0){
            v = c(v, Loadings[i,j+1]*hermgauss(wvl[w],j,mu=soapftrs$Gauss_mu[i], sig=soapftrs$Gauss_sig[i]))
          }else{
            v = c(v, Loadings[i,j]*hermgauss(wvl[w],j,mu=soapftrs$Gauss_mu[i], sig=soapftrs$Gauss_sig[i]))
          }
        }
      }
      if(j==0){
        X[,j+2] = v
      }else{
        X[,j+1] = v
      }
    }
    diff1 = tempflx[keep] - obsflx[keep]
    mdl1 = lm(diff1 ~ 0 + X, weights = 1/obsunc[keep]^2)
    mdl1inf = lm.influence(mdl1)
    influence = mdl1inf$wt.res*mdl1inf$hat/(1 - mdl1inf$hat)
    goodinf = which(abs(influence) <= median(influence) + 
                      quantile(influence, 0.75) + 50*IQR(influence))
    mdl = lm(diff1[goodinf] ~ 0 + X[goodinf,], 
             weights = 1/obsunc[keep][goodinf]**2)
    return(coef(mdl))
  }
  
  cfs = parallel::mclapply(1:length(spectra), safefit, mc.cores = cores)
  mdncoefs = apply(sapply(cfs, function(k) k), 1, median)
  
  safefit = function(tau){
    wvl = c()
    tempflx = c()
    obsflx = c()
    obsunc = c()
    for(i in 1:length(leftcutoffs)){
      keep = which(spectra[[tau]]$Wavelength > leftcutoffs[i] &
                     spectra[[tau]]$Wavelength < rightcutoffs[i])
      tkeep = which(template$Wavelength >= leftcutoffs[i] &
                      template$Wavelength <= rightcutoffs[i])
      if(length(tkeep) > 5 & length(keep) > 5){
        wvl = c(wvl, spectra[[tau]]$Wavelength[keep])
        obsflx = c(obsflx, spectra[[tau]]$Flux[keep])
        tempflx = c(tempflx, wave_match(template$Wavelength[tkeep], 
                                        template$Flux[tkeep],
                                        spectra[[tau]]$Wavelength[keep]))
        if("Uncertainty" %in% names(spectra[[tau]])){
          obsunc = c(obsunc, spectra[[tau]]$Uncertainty[keep])
        }else{
          obsunc = c(obsunc, sqrt(tempflx[(length(obsunc)+1):length(tempflx)]))
        }
      }
    }
    
    nonans = which(!is.na(obsflx))
    wvl = wvl[nonans]
    obsflx = obsflx[nonans]
    obsunc = obsunc[nonans]
    tempflx = tempflx[nonans]
    keep = which((wvl >= minwvl) & (wvl <= maxwvl))
    wvl = wvl[keep]
    obsflx = obsflx[keep]
    obsunc = obsunc[keep]
    tempflx = tempflx[keep]
    
    keep = c()
    doppvar = c()
    for(i in 1:(dim(soapftrs)[1])){
      w = which((wvl <= soapftrs$Wv_ubounds[i]) & (wvl >= soapftrs$Wv_lbounds[i]))
      if(length(w) > 3){
        keep = c(keep, w)
        diff = tempflx[w] - doppshift(wvl[w], tempflx[w], 20)
        x_design = sapply(0:5, function(d) hermgauss(wvl[w],d,mu=soapftrs$Gauss_mu[i],sig=soapftrs$Gauss_sig[i]))
        mdl = lm(diff ~ 0 + x_design)
        doppvar = c(doppvar, as.numeric(mdl$fitted.values)/20)
      }
    }
    Loadings = as.matrix(soapftrs[c("SOAPamp_0", "SOAPamp_2",
                                    "SOAPamp_3", "SOAPamp_4",
                                    "SOAPamp_5")])
    X = matrix(nrow = length(doppvar), ncol = 6)
    X[,1] = doppvar
    for(j in c(0,2,3,4,5)){
      v = c()
      for(i in 1:(dim(soapftrs)[1])){
        w = which((wvl <= soapftrs$Wv_ubounds[i]) &
                    (wvl >= soapftrs$Wv_lbounds[i]))
        if(length(w) > 3){
          if(j==0){
            v = c(v, Loadings[i,j+1]*hermgauss(wvl[w],j,mu=soapftrs$Gauss_mu[i], sig=soapftrs$Gauss_sig[i]))
          }else{
            v = c(v, Loadings[i,j]*hermgauss(wvl[w],j,mu=soapftrs$Gauss_mu[i], sig=soapftrs$Gauss_sig[i]))
          }
        }
      }
      if(j==0){
        X[,j+2] = v
      }else{
        X[,j+1] = v
      }
    }
    
    tempflx[keep] = tempflx[keep] - X%*%mdncoefs
    diff1 = tempflx[keep] - obsflx[keep]
    mdl1 = lm(diff1 ~ 0 + X, weights = 1/obsunc[keep]^2)
    mdl1inf = lm.influence(mdl1)
    influence = mdl1inf$wt.res*mdl1inf$hat/(1 - mdl1inf$hat)
    goodinf = which(abs(influence) <= median(influence) + 
                      quantile(influence, 0.75) + 50*IQR(influence))
    mdl = lm(diff1[goodinf] ~ 0 + X[goodinf,], 
             weights = 1/obsunc[keep][goodinf]**2)
    mdl2 = lm(diff1[goodinf] ~ 0 + X[goodinf,1],
              weights = 1/obsunc[keep][goodinf]**2)
    ftest = anova(mdl2, mdl)
    return(list(p = ftest$`Pr(>F)`[2], fstat = ftest$F[2],
                N = length(diff1),
                pars = coef(mdl), 
                tstat = summary(mdl)$coefficients[,3]))
  }
  
  rslts = parallel::mclapply(1:length(spectra), safefit, mc.cores = cores)
  return(data.frame(Pvals = sapply(rslts, function(r) r$p),
              SAFE = sapply(rslts, function(r) r$fstat),
              Ns = sapply(rslts, function(r) r$N),
              b1 = sapply(rslts, function(r) as.numeric(r$pars)[1]),
              b0 = sapply(rslts, function(r) as.numeric(r$pars)[2]),
              b2 = sapply(rslts, function(r) as.numeric(r$pars)[3]),
              b3 = sapply(rslts, function(r) as.numeric(r$pars)[4]),
              b4 = sapply(rslts, function(r) as.numeric(r$pars)[5]),
              b5 = sapply(rslts, function(r) as.numeric(r$pars)[6]),
              t1 = sapply(rslts, function(r) as.numeric(r$tstat)[1]),
              t0 = sapply(rslts, function(r) as.numeric(r$tstat)[2]),
              t2 = sapply(rslts, function(r) as.numeric(r$tstat)[3]),
              t3 = sapply(rslts, function(r) as.numeric(r$tstat)[4]),
              t4 = sapply(rslts, function(r) as.numeric(r$tstat)[5]),
              t5 = sapply(rslts, function(r) as.numeric(r$tstat)[6])))
  
}


