## Resubmission
This is a resubmission. In this version I have:

* Updated the version number to be 0.2.0

* Added a few options to the *estimate_template()* and *gaussfit()* functions to make them more flexible

* Added *alisnspec()*, *calc_safe()*, and *renormalize()* functions to implement the SAFE methodology

## Test environments
* local OS X install, R 4.0.0
* ubuntu 7.7 (Maipo), R 3.6.1

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs.

