* version **0.1.0** : original version with the basic functions used to estimate the radial velocity in stellar spectra

* version **0.1.1** : fixed a couple small bugs in the *gaussfit( )* function to allow for easier parallelization

* version **0.1.2** : a few more bugs fixed in the *gaussfit( )*
function so that it works on high-dimensional spectra

* version **0.2.0** : added in functions for calculating the Stellar Activity F-statistic for Exoplanet surveys, together with improving the *gaussfit( )* and *estimate_template( )* functions to be more flexible