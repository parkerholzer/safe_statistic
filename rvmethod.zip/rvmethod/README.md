The **rvmethod** package is designed to implement the Radial Velocity (RV) method for detecting exoplanets through the periodic motion of their host star. Particularly, this uses the methodology from Holzer et. al (2020) that introduces the Hermite-Gaussian Radial Velocity (HGRV) approach that uses a linear regression model to estimate the radial velocity.

The process of implementing this method through this package is the following sequence of steps:

* feed a time-series of normalized stellar spectra into the function *estimate_template( )* to estimate the template spectrum
* apply the absorption feature finding algorithm to the estimated template by feeding it into the *findabsorptionfeatures( )* function
* fit Gaussians to the absorption features found in the template spectrum with the *gaussfit( )* function
* estimate the RV in each stellar spectrum by feeding the estimated template spectrum and Gaussian fit parameters into the *hgrv( )* function

The package also includes functions for calculating the Stellar Activity F-statistic for Exoplanet surveys (SAFE). To calculate the SAFE, the following sequence is recommended:

* feed a time-series of normalized stellar spectra into the function *estimate_template( )* together with HGRV-estimated RV's as the *vels* argument to get an initial estimate of the template spectrum
* use the *renormalize( )* function to adjust the continuum of each stellar spectrum
* re-estimate the template spectrum using the *estimate_template( )* function with the renormalized spectra and the same set of RV's as before
* calculate the SAFE by feeding the set of renormalized spectra and the estimated template spectrum into the *calc_safe( )* function

To install the package, run the following command in R: install.packages("rvmethod") 

Along with the functions mentioned in the sequences above, there are some example data sets that are used in examples given in the documentation.